import redis

r = redis.Redis(
    host='localhost')
r.set('name','srini')
print(r.get('name'));
seq = [1, 2, 3]

r.rpush('key', seq)
r.lpush('key1',2345)
print(r.lrange('key',0,20))
print(r.exists('name'))
r.expire('name',1)
print(r.exists('name'))
print('Lenght of my cache is',r.llen('key'))
r.sadd('my.set', 1, 2, 3)
print(r.smembers('my.set'))
print(type(r.smembers('my.set')))
print(r.spop('my.set'))
print('Set members are ',r.smembers('my.set'))