
class JustCounter:
   __secretCount = 0
   bond = 0
  
   def count(self):
      self.__secretCount += 1
      print(self.__secretCount)

counter = JustCounter()
counter.count()
counter.count()
print(counter.bond)
print(counter.__secretCount,bond)