class Example:
    staticVariable = 5 

print(Example.staticVariable)

# All variables defined on the class level in Python are considered static.
instance = Example()
print(instance.staticVariable)


instance.staticVariable = 6
print (instance.staticVariable )
print (Example.staticVariable) 


class Example.staticVariable = 7
print (instance.staticVariable) 
print (Example.staticVariable)