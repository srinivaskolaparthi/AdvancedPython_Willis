class MyClass(object):
    #a=90
    @staticmethod
    def the_static_method(x):
        print(x)

MyClass.the_static_method(2)