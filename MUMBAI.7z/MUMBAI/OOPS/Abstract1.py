from abc import ABCMeta, abstractmethod
#An abstract method can also have an implementation, but it can only be invoked with super from a derived class.
class Animal:
    __metaclass__ = ABCMeta

    @abstractmethod
    def say_something(self):
          return "I'm an animal!"

class Cat(Animal):
    def say_something(self):
        s = super(Cat, self).say_something()
        return "%s - %s" % (s, "kolaparthi")

c = Cat()
print(c.say_something())		