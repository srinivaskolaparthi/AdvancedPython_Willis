from enum import Enum
class Color(Enum):
     RED = 1
     GREEN = 2
     BLUE = 3
     SRINI=auto()

print(Color.RED)
print(Color.RED.name)
print(isinstance(Color.GREEN, Color))
print(Color['RED'])
print(Color['RED'].value)
