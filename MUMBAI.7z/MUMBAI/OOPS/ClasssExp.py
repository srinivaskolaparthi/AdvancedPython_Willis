class Dog:

    kind = 'Kindleware'         

    def __init__(self, name):
        self.name = name   

d = Dog('Srini')
e = Dog('Buddy')
d.kind                

e.kind                  
d.name                  
e.name                  
