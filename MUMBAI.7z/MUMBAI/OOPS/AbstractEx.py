from abc import ABC, abstractmethod

from abc import ABC, abstractmethod
class Abstract(ABC):
    @abstractmethod
    def srini(self):
        pass

abc =Abstract()
abc.srini()