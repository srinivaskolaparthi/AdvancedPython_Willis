from abc import ABC, abstractmethod

from abc import ABC, abstractmethod
class Abstract(ABC):
    @abstractmethod
    def foo(self):
        pass

abc =Abstract()
abc.foo()