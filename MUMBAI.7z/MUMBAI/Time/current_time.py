import time;
#get current Time
localtime = time.localtime(time.time())
print( "Local current time :", localtime)
#formatted time
localtime = time.asctime( time.localtime(time.time()) )
print ("Local current time :", localtime)

#calendar display
import calendar

cal = calendar.month(2008, 1)
print( "Here is the calendar:")
print (cal)