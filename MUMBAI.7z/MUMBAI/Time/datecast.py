import datetime
date_text = "13SEP2014"
date = datetime.datetime.strptime(date_text, "%d%b%Y")
print(date)