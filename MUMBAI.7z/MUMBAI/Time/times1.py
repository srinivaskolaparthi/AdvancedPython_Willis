import time
print(time.strftime('%a %H:%M:%S'))
