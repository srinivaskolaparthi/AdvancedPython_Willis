A = {1, 2, 3, 4, 5}
B = {4, 5, 6, 7, 8}

print(A | B)
print(A.union(B))
print(A.intersection(B))
print(A.difference(B))
print(A-B)

my_set = {1.0, "Hello", (1, 2, 3)}
print(my_set)


a = {}

print(type(a))

# initialize a with set()
a = set()

print(type(a))
print(a.add(4))
print(a)

a.add(2)
print(a)
