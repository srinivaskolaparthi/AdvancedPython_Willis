str = 'kolaparthi'
print('str = ', str)

print('str[0] = ', str[0])
print('str[-1] = ', str[-1])
print('str[1:5] = ', str[1:5])
print('str[5:-2] = ', str[5:-4])
#str[1]='p'#cannot assign?
#del str[1]

#2nd Examp

count = 0
for letter in 'WIllis Account':
    if(letter == 'l'):
        count += 1
print(count,'letters found')
print('W' in 'Willisss')
print('KolapaArthi'.lower())