import sys

one = []
b;
print ('At start         :', sys.getrefcount(one))

two = one

print ('Second reference :', sys.getrefcount(two))

del two

print ('After del        :', sys.getrefcount(one))