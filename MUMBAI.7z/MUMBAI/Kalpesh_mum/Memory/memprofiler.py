#python -m memory_profiler example.py
@profile
def my_func():
    a =  (10 ** 6)
    b =  (2 * 10 ** 7)
    del b
    return a

@profile
def test_1(i):
    # .. will be called twice ..
    c = {}
    for i in range(i):
        c[i] = 2
		
if __name__ == '__main__':
    #my_func()
	test_1(10000)
	