from guppy import hpy 
#Needs Visual Studio

h = hpy() 

print(h.heap())