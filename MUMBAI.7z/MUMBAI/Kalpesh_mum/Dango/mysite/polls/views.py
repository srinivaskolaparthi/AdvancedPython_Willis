from django.http import HttpResponse


def indexs(request):
    return HttpResponse("Hello, world. You're at the polls index.")
	
def sri(request):
    return HttpResponse("Hello, world. You' srire at the polls index.")	