import base64
Str = "sap";
encppt=base64.b64encode(b'Str')
print(encppt)
print("Decrypting")
print(base64.b64decode(encppt))
