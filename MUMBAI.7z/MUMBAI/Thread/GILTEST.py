__author__ = 'srinivas K'
from datetime import datetime
import threading 
def factorial(number): 
    fact = 1
    for n in range(1, number+1): 
        fact *= n 
    return fact 
number = 100000 
thread = threading.Thread(target=factorial, args=(number,)) 
startTime = datetime.now() 
thread.start() 
thread.join() 
endTime = datetime.now() 
print ("Time for execution: ",thread.getName() ,endTime - startTime)

#-------------------------
thread1 = threading.Thread(target=factorial, args=(number,)) 
startTime1 = datetime.now() 
thread1.start() 
thread1.join() 
endTime1 = datetime.now() 
print ("Time for execution: ",thread1.getName() ,endTime1 - startTime1)
print("========================================================")
print("Over all Execution Time for Threads:",endTime1-startTime)
print("======================================================")
print(threading.active_count())