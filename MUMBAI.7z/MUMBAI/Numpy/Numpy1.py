import numpy as np 
a = 'hello world' 
print(a[0])

a1 = np.array([[1,2,3],[4,5,6]]) 
a1.shape = (3,2) 
print ("Shape",a )

#-------------------------------

print( 'Concatenate two strings:' )
print( np.char.add(['hello'],[' xyz'])) 
print ('\n')

print ('Concatenation example:' )
print (np.char.add(['hello', 'hi'],[' abc', ' xyz']))

#--------------Slicing

a = np.arange(10) 
s = slice(2,7,2) #start stop step
print( a[s])
print (a[2:5])

#---nditer predined iterator


a2 = np.arange(0,60,5)
a2 = a2.reshape(3,4)

print ('Original array is:')
print (a)
print ('\n')

print 'Modified array is:'
for x in np.nditer(a2):
   print (x)