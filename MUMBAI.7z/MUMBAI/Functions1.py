def printinfo( name, age = 35 ):
   "This prints a passed info into this function"
   print("Name: ", name)
   print("Age ", age)
   return;

printinfo( age=50, name="kolaparthi" )
printinfo( name="kolaparthi" )