from multiprocessing import Lock

l = Lock()
a=9
l.acquire()
print( 'Ha! I can write to stdout and srini!')
l.release()