def print_everything(*args):
        for count, thing in enumerate(args):
          print( '{0}. {1}'.format(count, thing))

print_everything('Willis', 'discover', 'Scope account')

def table_things(**kwargs):
     for name, value in kwargs.items():
        print( '{0} = {1}'.format(name, value))

table_things(apple = 'fruit', trainer = 'srinivas Kolaparthi')